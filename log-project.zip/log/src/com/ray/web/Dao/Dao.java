package com.ray.web.Dao;

import com.ray.web.service.User;

import java.sql.SQLException;
import java.util.List;

public interface Dao {
    int queryCount();
    int queryCount(String[] str,int a, int b);
    List query(int a, int b);
    List query(String[] str,int a, int b);
    boolean queryAdmin(int aid, String apw);
    List delete(int[] arr) throws SQLException;
    boolean add(User user) throws SQLException;
    int update(User user);
}
