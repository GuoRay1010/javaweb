package com.ray.web.Dao;

import com.ray.web.service.User;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DaoImpl implements Dao {
    @Override
    public boolean queryAdmin(int aid, String apw) {
        String sql = "select aid from admininfo where aid=? and apw=?";
        PreparedStatement adminPS = null;
        Connection connection =null;
        ResultSet resultSet = null;
        try {
            connection = AdminTemplateUtil.getConnection();
            adminPS = connection.prepareStatement(sql);
            adminPS.setInt(1, aid);
            adminPS.setString(2, apw);
            resultSet = adminPS.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }finally {
            close(adminPS, connection, resultSet);
        }
    }

    public static List userPS(String sql,String[] str,int a,int b){
        String[] temp = {"name", "hometown", "email"};
        try {
            int n = 0;
            boolean[] boo = new boolean[3];
            sql = getSql(sql, str, temp, n, boo);
            sql=sql+" limit "+a+","+b;
            Connection connection = UserTemplateUtil.getConnection();
            PreparedStatement userPS = connection.prepareStatement(sql);
            int m = 1;
            for (int i = 0; i < 3; i++) {
                if (boo[i]) {
                    userPS.setString(m, str[i]);
                    m++;
                }
            }
            List list = new ArrayList();
            list.add(connection);
            list.add(userPS);
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static List userPS(String sql,String[] str){
        String[] temp = {"name", "hometown", "email"};
        try {
            int n = 0;
            boolean[] boo = new boolean[3];
            sql = getSql(sql, str, temp, n, boo);
            Connection connection = UserTemplateUtil.getConnection();
            PreparedStatement userPS = connection.prepareStatement(sql);
            int m = 1;
            for (int i = 0; i < 3; i++) {
                if (boo[i]) {
                    userPS.setString(m, str[i]);
                    m++;
                }
            }
            List list = new ArrayList();
            list.add(connection);
            list.add(userPS);
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String getSql(String sql, String[] str, String[] temp, int n, boolean[] boo) {
        for (int i = 0; i < str.length; i++) {
            if (str[i] != null) {
                if (n == 0) {
                    sql = sql + " where " + temp[i] + "=?";
                } else {
                    sql = sql + "and" + temp[i] + "=?";
                }
                n++;
                boo[i] = true;
            } else {
                boo[i] = false;
            }
        }
        return sql;
    }

    @Override
    public int queryCount() {
        String sql = "select count(0) from userinfo";
        PreparedStatement userPS = null;
        Connection connection = null;
        ResultSet resultSet = null;
        try {
            connection = UserTemplateUtil.getConnection();
            userPS = connection.prepareStatement(sql);
            userPS.execute();
            resultSet = userPS.getResultSet();
            resultSet.next();
            return resultSet.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }finally {
            close(userPS, connection, resultSet);
        }
    }

    private void close(PreparedStatement userPS, Connection connection, ResultSet resultSet) {
        try {
            resultSet.close();
            userPS.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int queryCount(String[] str,int a,int b) {
        String sql = "select count(0) from userinfo";
        List list = userPS(sql,str);
        PreparedStatement userPS = (PreparedStatement) list.get(1);
        Connection connection = (Connection) list.get(0);
        ResultSet resultSet = null;
        try {
            resultSet = userPS.executeQuery();
            resultSet.next();
            return resultSet.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }finally {
            close(userPS, connection, resultSet);
        }
    }

    @Override
    public List query(int a, int b) {
        String sql = "select * from userinfo limit " + a + "," + b;
        JdbcTemplate userTemplate = UserTemplateUtil.getTemplate();
        List<User> list = userTemplate.query(sql, new BeanPropertyRowMapper<>(User.class));
        return list;
    }

    @Override
    public List query(String[] str, int a, int b) {
        String sql = "select * from userinfo";
        List list1 = userPS(sql, str, a, b);
        PreparedStatement userPS = (PreparedStatement) list1.get(1);
        Connection connection = (Connection) list1.get(0);
        List list = new ArrayList();
        ResultSet resultSet = null;
        try {
            resultSet = userPS.executeQuery();
            while (resultSet.next()) {
                list.add(new User(resultSet.getInt(1), resultSet.getString(2),
                        resultSet.getBoolean(3), resultSet.getInt(4),
                        resultSet.getString(5), resultSet.getInt(6),
                        resultSet.getString(7)));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            close(userPS, connection, resultSet);
        }
        return list;
    }

    @Override
    public boolean add(User user) {
        String sql = "insert into userinfo values(?,?,?,?,?,?,?)";
        int i = 1;
        Map userMap = null;
        PreparedStatement userPS =null;
        Connection connection = null;
        try {
            connection = UserTemplateUtil.getConnection();
            userPS = connection.prepareStatement(sql);
            userMap = BeanUtils.describe(user);
            userPS.setInt(1, Integer.parseInt((String) userMap.get("uid")));
            userPS.setString(2, (String) userMap.get("name"));
            boolean gender = ((String) userMap.get("gender")).equals("true");
            userPS.setBoolean(3, gender);
            userPS.setInt(4, Integer.parseInt(userMap.get("age") + ""));
            userPS.setString(5, (String) userMap.get("hometown"));
            userPS.setInt(6, Integer.parseInt(userMap.get("QQ") + ""));
            userPS.setString(7, (String) userMap.get("email"));
            return !userPS.execute();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return false;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return false;
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }finally {
            try {
                userPS.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public List delete(int[] arr) throws SQLException {
        String sql = "delete from userinfo where uid = ?";
        List list = new ArrayList();
        PreparedStatement userPS = UserTemplateUtil.getConnection().prepareStatement(sql);
        for (int i = 0; i < arr.length; i++) {
            try {
                userPS.setInt(1, arr[i]);
                list.add(!userPS.execute());
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        userPS.close();
        return list;
    }

    @Override
    public int update(User user) {
        String sql = "update userinfo set name=? ,gender=? ,age=? ,hometown=? ,QQ=? ,email=? where uid=?";
        PreparedStatement userPS = null;
        Connection connection = null;
        int i = -1;
        try {
            connection = UserTemplateUtil.getConnection();
            userPS = connection.prepareStatement(sql);
            userPS.setString(1, user.getName());
            userPS.setBoolean(2, user.isGender());
            userPS.setInt(3, user.getAge());
            userPS.setString(4, user.getHometown());
            userPS.setInt(5, user.getQQ());
            userPS.setString(6, user.getEmail());
            userPS.setInt(7, user.getUid());
            i = userPS.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                userPS.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i;
    }
}

