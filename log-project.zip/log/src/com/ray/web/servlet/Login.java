package com.ray.web.servlet;

import com.ray.web.service.Admin;
import com.ray.web.service.LinkDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class Login extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String vcodeGenerate = (String) session.getAttribute("vcode");
        session.removeAttribute("vcode");
        String vocdeGet = (String) request.getParameter("verifycode");

        if(vcodeGenerate.equals(vocdeGet)){
            Admin admin = new Admin(Integer.parseInt(request.getParameter("user")),request.getParameter("password"));
            boolean flag = new LinkDaoImpl().queryList(admin);
            if(flag){
                request.getRequestDispatcher("/List").forward(request,response);
            }else{
                request.setAttribute("vcodeStatus",false);
                request.getRequestDispatcher("login.jsp").forward(request,response);
            }
        }else{
            request.setAttribute("vcodeStatus",false);
            request.getRequestDispatcher("login.jsp").forward(request,response);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

}
