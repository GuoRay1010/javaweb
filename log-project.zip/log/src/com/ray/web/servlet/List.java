package com.ray.web.servlet;

import com.ray.web.Dao.DaoImpl;
import com.ray.web.service.LinkDaoImpl;
import com.ray.web.service.PageBean;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/List")
public class List extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        int rows = 5;
        if(request.getParameter("rows")!=null){
            rows = Integer.parseInt(request.getParameter("rows"));
        }
        int currentPage = 1;
        if(request.getParameter("currentPage")!=null){
            currentPage = Integer.parseInt(request.getParameter("currentPage"));
        }

        int totalCount = new DaoImpl().queryCount();
        int totalPage = totalCount%rows==0?totalCount/rows:totalCount/rows+1;
        java.util.List list = new LinkDaoImpl().queryList((currentPage-1)*rows,rows);
        PageBean pb = new PageBean(totalCount,totalPage,currentPage,list);

        request.setAttribute("pb",pb);
        request.setAttribute("rows",rows);
        request.setAttribute("from",1);
        request.getRequestDispatcher("list.jsp").forward(request,response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
