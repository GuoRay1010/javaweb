package com.ray.web.servlet;

import com.ray.web.Dao.DaoImpl;
import com.ray.web.service.LinkDaoImpl;
import com.ray.web.service.PageBean;
import com.ray.web.service.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/QueryWithTerms")
public class QueryWithTerms extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        HttpSession session = request.getSession();
        int rows = 5;
        if (request.getParameter("rows") != null) {
            rows = Integer.parseInt(request.getParameter("rows"));
        }
        int currentPage = 1;
        if (request.getParameter("currentPage") != null) {
            currentPage = Integer.parseInt(request.getParameter("currentPage"));
        }

        Map<String, String[]> map = request.getParameterMap();
        User user = new User(map.get("username")[0], map.get("hometown")[0],
                map.get("email")[0]);
        session.removeAttribute("flag");
        session.setAttribute("flag", user);
        request.setAttribute("searched1", map.get("username")[0]);
        request.setAttribute("searched2", map.get("hometown")[0]);
        request.setAttribute("searched3", map.get("email")[0]);

        List list = new LinkDaoImpl().queryList(user, (currentPage - 1) * rows, rows);

        int totalCount = new LinkDaoImpl().queryCount(user, (currentPage - 1) * rows, rows);
        int totalPage = totalCount % rows == 0 ? totalCount / rows : totalCount / rows + 1;
        PageBean pb = new PageBean(totalCount, totalPage, currentPage, list);
        request.setAttribute("pb", pb);

        request.setAttribute("from", 0);
        request.getRequestDispatcher("list.jsp").forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
