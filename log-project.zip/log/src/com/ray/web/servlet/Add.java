package com.ray.web.servlet;

import com.ray.web.service.LinkDaoImpl;
import com.ray.web.service.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@WebServlet("/Add")
public class Add extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        Map<String, String[]> map = request.getParameterMap();
        User user = new User(Integer.parseInt(map.get("uid")[0]),map.get("name")[0],
                Integer.parseInt(map.get("sex")[0]) == 1,
                Integer.parseInt(map.get("age")[0]),map.get("address")[0],
                Integer.parseInt(map.get("qq")[0]),map.get("email")[0]);
        boolean flag = new LinkDaoImpl().add(user);
        if(flag){
            response.getWriter().write("添加成功");
            response.getWriter().write("添加成功");
        }else{
            response.getWriter().write("添加失败");
            response.getWriter().write("添加失败");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
