package com.ray.web.servlet;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

@WebServlet("/verify_code")
public class VerifyCode extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int width = 100;
        int height = 50;

        BufferedImage img = new BufferedImage(width,height,BufferedImage.TYPE_3BYTE_BGR);
        Graphics gra = img.getGraphics();
        gra.setColor(Color.pink);
        gra.fillRect(0,0,width,height);
        //48-57,65-90,97-122。ASCII表
        //10,26,26。字符数
        //0-62中产生随机数
        //判断随机数的范围，在1-10，是数字；11-36，大写字母；37-62，小写字母
        char[] chars = new char[4];
        Random ram = new Random();
        for (int i = 0; i < 4; i++) {
            int num = ram.nextInt(62);
            if(num<=10){
                chars[i] = (char) (num+47);
            }else if(num>=37){
                chars[i] = (char) (num+60);
            }else{
                chars[i] = (char) (num+54);
            }
        }

        String str = chars[0]+"";
        for (int i = 1; i < chars.length; i++) {
            str = str+chars[i]+"";
        }

        gra.setColor(Color.black);
        int x = ram.nextInt(20);
        int y = 25;
        for (int i = 0 ; i < chars.length; i++) {
            gra.drawString(chars[i]+"",x,y);
            x += 25;
        }

        ImageIO.write(img,"jpg",resp.getOutputStream());

        HttpSession session = req.getSession();
        session.setAttribute("vcode",str);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }
}
