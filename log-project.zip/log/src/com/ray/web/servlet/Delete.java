package com.ray.web.servlet;

import com.ray.web.service.LinkDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/Delete")
public class Delete extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String[] uid = request.getParameterValues("uid");
        int[] uids = new int[uid.length];
        for (int i = 0; i < uid.length; i++) {
            uids[i]=Integer.parseInt(uid[i]);
        }
        List<Boolean> delete = new LinkDaoImpl().delete(uids);
        for (int i = 0; i < delete.size(); i++) {
            String str = delete.get(i)?"成功":"失败";
            response.getWriter().write("ID为"+uids[i]+"的记录删除"+str+"<br>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
