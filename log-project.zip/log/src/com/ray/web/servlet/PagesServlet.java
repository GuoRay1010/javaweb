package com.ray.web.servlet;

import com.ray.web.service.LinkDaoImpl;
import com.ray.web.service.PageBean;
import com.ray.web.service.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/PagesServlet")
public class PagesServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        HttpSession session = request.getSession();
        int rows = Integer.parseInt(request.getParameter("rows"));
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));

        User user = (User) session.getAttribute("flag");
        session.setAttribute("searched1", user.getName()==null?"":user.getName());
        session.setAttribute("searched2", user.getHometown()==null?"":user.getHometown());
        session.setAttribute("searched3", user.getEmail()==null?"":user.getEmail());

        List list = new LinkDaoImpl().queryList(user, (currentPage - 1) * rows, rows);

        int totalCount = new LinkDaoImpl().queryCount(user, (currentPage - 1) * rows, rows);
        int totalPage = totalCount % rows == 0 ? totalCount / rows : totalCount / rows + 1;
        PageBean pb = new PageBean(totalCount, totalPage, currentPage, list);

        request.setAttribute("pb", pb);
        request.setAttribute("from", 0);
        request.getRequestDispatcher("list.jsp").forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
