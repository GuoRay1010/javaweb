package com.ray.web.service;

import com.ray.web.Dao.DaoImpl;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.util.StringUtils;

import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class LinkDaoImpl implements LinkDao {
    DaoImpl daoImpl = new DaoImpl();

    @Override
    public List queryList(int a,int b) {

        List list = daoImpl.query(a,b);
        return list;
    }

    @Override
    public List queryList(User user,int a, int b) {
        try {
            Map map = BeanUtils.describe(user);
            String[] str = new String[3];
            str[0] = StringUtils.isEmpty(map.get("name"))?null: (String) map.get("name");
            str[1] = StringUtils.isEmpty(map.get("hometown"))?null:(String) map.get("hometown");
            str[2] = StringUtils.isEmpty(map.get("email"))?null: (String) map.get("email");
            return daoImpl.query(str,a,b);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        return null;
    }

    public int queryCount(User user,int a, int b) {
        try {
            Map map = BeanUtils.describe(user);
            String[] str = new String[3];
            str[0] = StringUtils.isEmpty(map.get("name"))?null: (String) map.get("name");
            str[1] = StringUtils.isEmpty(map.get("hometown"))?null:(String) map.get("hometown");
            str[2] = StringUtils.isEmpty(map.get("email"))?null: (String) map.get("email");
            return daoImpl.queryCount(str,a,b);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return 0;
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            return 0;
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public boolean queryList(Admin admin) {
        return daoImpl.queryAdmin(admin.getAid(), admin.getApw());
    }

    @Override
    public List<Boolean> delete(int[] arr) {
        try {
            return daoImpl.delete(arr);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean add(User user) {
        return daoImpl.add(user);
    }

    @Override
    public boolean update(User user) {
        int update = daoImpl.update(user);
        if (update>0){
            return true;
        }else{
            return false;
        }
    }
}
