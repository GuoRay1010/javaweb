package com.ray.web.service;

import java.util.Objects;

public class User {
    private int uid;
    private String name;
    private boolean gender;
    private int age;
    private String hometown;
    private int QQ;
    private String email;

    public User() {
    }

    public User(String name, String hometown, String email) {
        this.name = name;
        this.hometown = hometown;
        this.email = email;
    }

    public User(int uid, String name, boolean gender, int age, String hometown, int QQ, String email) {
        this.uid = uid;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.hometown = hometown;
        this.QQ = QQ;
        this.email = email;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return uid == user.uid &&
                gender == user.gender &&
                age == user.age &&
                QQ == user.QQ &&
                Objects.equals(name, user.name) &&
                Objects.equals(hometown, user.hometown) &&
                Objects.equals(email, user.email);
    }

    @Override
    public int hashCode() {

        return Objects.hash(uid, name, gender, age, hometown, QQ, email);
    }

    @Override
    public String toString() {
        return "User{" +
                "uid=" + uid +
                ", name='" + name + '\'' +
                ", gender=" + gender +
                ", age=" + age +
                ", hometown='" + hometown + '\'' +
                ", QQ=" + QQ +
                ", email='" + email + '\'' +
                '}';
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getHometown() {
        return hometown;
    }

    public void setHometown(String hometown) {
        this.hometown = hometown;
    }

    public int getQQ() {
        return QQ;
    }

    public void setQQ(int QQ) {
        this.QQ = QQ;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
