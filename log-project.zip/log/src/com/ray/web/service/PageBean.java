package com.ray.web.service;

import java.util.List;
import java.util.Objects;

public class PageBean {
    private int totalCount;
    private int totalPage;
    private int currentPage;
    private List list;

    public PageBean() {
    }

    public PageBean(int totalCount, int totalPage, int currentPage, List list) {
        this.totalCount = totalCount;
        this.totalPage = totalPage;
        this.list = list;
        this.currentPage = currentPage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PageBean pageBean = (PageBean) o;
        return totalCount == pageBean.totalCount &&
                totalPage == pageBean.totalPage &&
                currentPage == pageBean.currentPage &&
                Objects.equals(list, pageBean.list);
    }

    @Override
    public int hashCode() {

        return Objects.hash(totalCount, totalPage, list, currentPage);
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }
}
