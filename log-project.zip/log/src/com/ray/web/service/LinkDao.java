package com.ray.web.service;

import java.sql.SQLException;
import java.util.List;

public interface LinkDao {
//    List queryList();
    List queryList(int a,int b);
    boolean queryList(Admin admin);
    List queryList(User user,int a, int b);
    List<Boolean> delete(int[] arr) throws SQLException;
    boolean add(User user);
    boolean update(User user);
}
