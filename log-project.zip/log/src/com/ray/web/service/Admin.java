package com.ray.web.service;

import java.util.Objects;

public class Admin {
    private int aid;
    private String apw;

    public Admin() {
    }

    public Admin(int aid, String apw) {
        this.aid = aid;
        this.apw = apw;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Admin admin = (Admin) o;
        return aid == admin.aid &&
                Objects.equals(apw, admin.apw);
    }

    @Override
    public int hashCode() {

        return Objects.hash(aid, apw);
    }

    @Override
    public String toString() {
        return "Admin{" +
                "aid=" + aid +
                ", apw='" + apw + '\'' +
                '}';
    }

    public int getAid() {
        return aid;
    }

    public void setAid(int aid) {
        this.aid = aid;
    }

    public String getApw() {
        return apw;
    }

    public void setApw(String apw) {
        this.apw = apw;
    }
}
